/*
 * Lab9.h
 *
 *  Created on: Mar. 24, 2022
 *      Author: JakeG
 */

#ifndef LAB9_H_
#define LAB9_H_


class Lab9 {
public:
	Lab9();
	~Lab9();
	void generateArrayOf50000RandomIntegers0To100000();
	void shellSortWithArray(int[]);
	void bubbleSortWithArray(int[]);
	int arrayOf50000Integers[50000];
};


#endif /* LAB9_H_ */
