/*
 * main.cpp
 *
 *  Created on: Feb. 3, 2022
 *      Author: JakeG
 */
#include <iostream>
#include <fstream>
#include <iostream>     // std::cout
#include <algorithm>    // std::sort
#include <vector>       // std::vector
#include "LinkedList.h"
#include "LinkedList.cpp"


int main() {
	int fileInteger;
	std::string filename("src/integerfile.txt");
	// C:\\Users\\JakeG\\eclipse-workspace\\Comp2412Lab3LinkedList\\src\\integerfile.txt
	LinkedList<int> *linkedListInteger = new LinkedList<int>;
	LinkedList<int> *linkedListIntegersFromFile = new LinkedList<int>;
	LinkedList<int> *linkedListAscendingIntegers = new LinkedList<int>;

	std::cout << "Appending the nodes 1 through 10 to the linked list of integers" << std::endl;
	for (int i = 0; i < 10; i++) {
		linkedListInteger->appendNode(i);
	}
	std::cout << "Here is the printed list of integer nodes that exist in the list: ";
	linkedListInteger->printListItem();

	std::cout << "Reading integers from the file\n";
	std::ifstream MyIntegerFile(filename);

	while (MyIntegerFile >> fileInteger) {
		linkedListIntegersFromFile->appendNode(fileInteger);
	}

	std::cout << "Reading integers from linked list: ";
	for (int i = 0; i < linkedListIntegersFromFile->length; i++) {
		std::cout << linkedListIntegersFromFile->getNodeAtIndex(i) << ' ';
	}

	int smallestInt = 0;
	int i = 0;
	linkedListAscendingIntegers->appendNode(11);
	while(i < linkedListIntegersFromFile->length) {
		if (smallestInt < linkedListIntegersFromFile->getNodeAtIndex(i)) {
			smallestInt = linkedListIntegersFromFile->getNodeAtIndex(i);
			linkedListAscendingIntegers->appendNode(smallestInt);
			i = 0;
			continue;
		}
		i++;
	}

	std::cout << "\n\n" << "Ascending ordered integers from smallest to largest: ";
	linkedListAscendingIntegers->printListItem();

	std::cout << std::endl;
	MyIntegerFile.close();

	return 0;
}

