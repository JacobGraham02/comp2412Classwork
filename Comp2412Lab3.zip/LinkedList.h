/*
 * LinkedList.h
 *
 *  Created on: Feb. 3, 2022
 *      Author: JakeG
 */

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

template<typename T>
struct Node {
	T data;
	Node<T>* next;
};

template<typename T>
class LinkedList {
public:
	int length;
	Node<T> *head;
	Node<T> *tail;

	LinkedList();
	~LinkedList();

	void prependNode(T data);
	void appendNode(T data);
	void deleteNodeAt(int index);
	void deleteNodesByValue(T value);
	void printListItem();
	T getNodeAtIndex(int index);
	int getSmallestInt();
	int getNodeIndexAtValue(T value);

	bool isEmpty() {
		return this->head == nullptr;
	}

	int lengthOfList() {
		return this->length;
	}
};

#endif /* LINKEDLIST_H_ */
