/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   Problem2.h
 * Author: JakeG
 *
 * Created on January 30, 2022, 2:33 p.m.
 */

#ifndef PROBLEM2_H
#define PROBLEM2_H
#include "stdbool.h"

typedef struct node {
    struct node* pointerToNode;
    char nodeCharData;
} STACK_NODE;
typedef struct {
    int numberOfItems;
    STACK_NODE* topOfStack;
} STACK;

bool pushStack(STACK* stack, char charData);
STACK_NODE* popStack(STACK* stack);
void convertIntToHexidecimal(STACK* stack, long int decimalInteger);
STACK* createStack(void);
int* stackTop(STACK* stack);
STACK* destroyStack(STACK* stack);

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* PROBLEM2_H */

